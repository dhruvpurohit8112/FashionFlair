-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 27, 2024 at 06:42 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `fashionflair`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `a_id` int(20) NOT NULL,
  `a_name` varchar(20) NOT NULL,
  `a_email` varchar(20) NOT NULL,
  `org` varchar(50) NOT NULL,
  `con_no` varchar(11) DEFAULT NULL,
  `address` varchar(150) NOT NULL,
  `a_pwd` varchar(20) NOT NULL,
  `profile_pic` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`a_id`, `a_name`, `a_email`, `org`, `con_no`, `address`, `a_pwd`, `profile_pic`) VALUES
(1, 'Alex', 'admin@gmail.com', 'En', '7845121012', 'Admin Address', 'admin', 'static/upload/1.png');

-- --------------------------------------------------------

--
-- Table structure for table `canceled_orders`
--

CREATE TABLE `canceled_orders` (
  `cancellation_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `prod_id` int(11) NOT NULL,
  `reason` text NOT NULL,
  `cancellation_date` datetime NOT NULL DEFAULT current_timestamp(),
  `status` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `canceled_orders`
--

INSERT INTO `canceled_orders` (`cancellation_id`, `order_id`, `customer_id`, `prod_id`, `reason`, `cancellation_date`, `status`) VALUES
(1, 43173, 1, 1, 'I ordered this by mistakely', '2024-04-09 12:56:46', 0),
(2, 64357, 2, 4, 'I wanna cancel this order ', '2024-04-10 13:05:10', 0),
(3, 84129, 1, 7, 'I ordered this by mistakely', '2024-04-10 13:07:46', 0);

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `cart_id` int(5) NOT NULL,
  `customer_id` int(5) NOT NULL,
  `prod_id` int(12) NOT NULL,
  `qty` int(5) NOT NULL DEFAULT 1,
  `status` varchar(150) NOT NULL DEFAULT 'unpaid'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`cart_id`, `customer_id`, `prod_id`, `qty`, `status`) VALUES
(1, 1, 1, 1, 'paid'),
(2, 1, 7, 1, 'paid'),
(6, 2, 4, 1, 'paid'),
(7, 1, 7, 1, 'paid'),
(8, 1, 6, 1, 'paid'),
(10, 1, 6, 1, 'paid'),
(11, 1, 6, 1, 'paid'),
(12, 1, 6, 1, 'paid'),
(13, 1, 4, 1, 'paid'),
(14, 1, 1, 1, 'paid');

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `cat_id` int(5) NOT NULL,
  `cat_name` varchar(30) NOT NULL,
  `cat_desc` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`cat_id`, `cat_name`, `cat_desc`) VALUES
(1, 'Male', 'Male category clothes encompass a variety of styles, from formal attire to casual wear, tailored to suit diverse masculine preferences and occasions.'),
(2, 'Female', 'Female category clothes encompass a wide range of styles, from formal dresses to casual attire, catering to diverse feminine preferences and occasion.');

-- --------------------------------------------------------

--
-- Table structure for table `complain`
--

CREATE TABLE `complain` (
  `c_id` int(20) NOT NULL,
  `c_msg` varchar(500) NOT NULL,
  `c_reply` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `contact_us`
--

CREATE TABLE `contact_us` (
  `con_id` int(5) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `subject` varchar(100) NOT NULL,
  `message` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `customer_id` int(4) NOT NULL,
  `name` varchar(150) NOT NULL,
  `customer_email` varchar(50) NOT NULL,
  `customer_pwd` varchar(15) NOT NULL,
  `gender` enum('male','female') NOT NULL,
  `contact` varchar(15) NOT NULL,
  `address` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`customer_id`, `name`, `customer_email`, `customer_pwd`, `gender`, `contact`, `address`) VALUES
(1, 'Alexa', 'thundergodff1996@gmail.com', 'Alexa@123', 'female', '7777777777', 'Alex home address '),
(2, 'name', 'thundergodff1996@gmail.com', 'Password@123', 'male', '8569854102', 'Address');

-- --------------------------------------------------------

--
-- Table structure for table `delivery`
--

CREATE TABLE `delivery` (
  `o_id` int(10) NOT NULL,
  `c_id` int(20) NOT NULL,
  `prod_id` int(10) NOT NULL,
  `m_trans` varchar(30) NOT NULL,
  `o_date` date NOT NULL DEFAULT current_timestamp(),
  `o_time` time NOT NULL DEFAULT current_timestamp(),
  `o_status` int(5) DEFAULT 0,
  `qty` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `f_id` int(15) NOT NULL,
  `c_id` int(20) NOT NULL,
  `f_msg` int(100) NOT NULL,
  `f_reply` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `id` int(123) NOT NULL,
  `user_message` varchar(2555) NOT NULL,
  `bot_message` varchar(2555) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `offers`
--

CREATE TABLE `offers` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(50) NOT NULL,
  `code` varchar(20) NOT NULL,
  `description` varchar(150) NOT NULL,
  `discount_value` decimal(10,0) NOT NULL,
  `st_date` datetime NOT NULL DEFAULT current_timestamp(),
  `end_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `offers`
--

INSERT INTO `offers` (`id`, `title`, `code`, `description`, `discount_value`, `st_date`, `end_date`) VALUES
(1, 'Fashion300', 'FF300', ' Get ₹300 off your purchase with our exclusive discount coupon code. Don\'t miss out on savings—redeem now for great deals! ', 300, '2024-04-09 12:51:26', '2024-04-15'),
(3, '100Rs Flat Coupen', 'FF100', 'Get 100rs off on your purchase for any product', 100, '2024-04-15 11:18:51', '2024-04-17');

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `o_id` int(20) NOT NULL,
  `prod_id` int(23) NOT NULL,
  `acc_num` varchar(20) NOT NULL,
  `cat_id` int(30) NOT NULL,
  `c_id` int(10) NOT NULL,
  `m_trans` varchar(23) NOT NULL,
  `v_code` varchar(23) NOT NULL,
  `pay_id` int(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `prod_id` int(20) NOT NULL,
  `prod_name` varchar(100) NOT NULL,
  `prod_code` varchar(15) NOT NULL,
  `prod_date` date NOT NULL DEFAULT current_timestamp(),
  `prod_time` time(6) NOT NULL DEFAULT current_timestamp(),
  `prod_price` int(9) NOT NULL,
  `prod_desc` varchar(1000) NOT NULL,
  `prod_img` varchar(2000) NOT NULL,
  `cat_id` int(15) NOT NULL,
  `sub_cat_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`prod_id`, `prod_name`, `prod_code`, `prod_date`, `prod_time`, `prod_price`, `prod_desc`, `prod_img`, `cat_id`, `sub_cat_id`) VALUES
(1, 'Men Blue Slim Fit Checks Cotton Full Sleeve Shirts', 'a50721b6', '2024-04-08', '18:02:07.000000', 1500, 'Crafted from breathable cotton, this slim-fit blue checks shirt for men offers both style and comfort. Ideal for casual or semi-formal occasions, it exudes sophistication with its tailored fit.', 'static/upload/XMSS11767-B5.JPG', 1, 1),
(3, 'Men Fawn Neo Classic Fit Print Cotton ', '01cf723e', '2024-04-09', '12:36:17.000000', 1500, 'Experience timeless style with this men\'s fawn neo classic fit shirt crafted from comfortable cotton and featuring a sophisticated print.', 'static/upload/PMTB07078-F4.JPG', 1, 3),
(4, 'Men Grey Regular Fit Checkered Polyester Rayon', '482f08c2', '2024-04-09', '12:39:48.000000', 1100, 'Effortlessly chic, this men\'s grey regular fit shirt boasts a classic checkered pattern and a blend of polyester and rayon for comfort.', 'static/upload/PMTX07523-G8.JPG', 1, 3),
(5, 'Men White Slim Fit Print Cotton Round Neck Collar Polo T-Shirt', '0ef1ce93', '2024-04-09', '12:42:17.000000', 900, 'Upgrade your casual ensemble with this men\'s white slim fit polo t-shirt, featuring a stylish print and a comfortable round neck collar.', 'static/upload/PMKA00515-W1.JPG', 1, 2),
(6, 'Men Medium Blue Solid Slim Fit Casual Polo', 'e1cfad46', '2024-04-09', '12:44:49.000000', 1100, 'Elevate your casual wardrobe with this men\'s medium blue solid slim fit polo, perfect for effortlessly stylish everyday wear.', 'static/upload/6383370085_PMKB00475-B3.JPG', 1, 2),
(7, 'Fashionable Ladies Kurta', '0ab7c1c3', '2024-04-09', '12:47:20.000000', 3000, 'We have gained recognition as an eminent enterprise, devotedly engaged in manufacturing a broad range of Fashionable Ladies Kurta.', 'static/upload/fashionable-ladies-kurta-1000x1000.jpg', 2, 5);

-- --------------------------------------------------------

--
-- Table structure for table `review`
--

CREATE TABLE `review` (
  `rw_id` int(5) NOT NULL,
  `user_id` int(5) NOT NULL,
  `prod_id` int(11) NOT NULL,
  `rating` int(5) NOT NULL,
  `review` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `review`
--

INSERT INTO `review` (`rw_id`, `user_id`, `prod_id`, `rating`, `review`) VALUES
(1, 1, 1, 5, 'I highly recommend this shirt. It\'s a great addition to any wardrobe. \r\n💙✨'),
(2, 1, 4, 5, 'The men\'s grey regular fit checkered polyester-rayon pants are of excellent quality, offering comfort, durability, and stylish design. Highly recommended!'),
(3, 1, 7, 5, 'This fashionable Ladies Kurta effortlessly blends elegance with contemporary style. Its intricate embroidery and vibrant color palette add a touch of sophistication to any ensemble. Crafted from high-quality fabric, it offers comfort and durability. Perfect for both casual outings and special occasions, it\'s a must-have addition to any wardrobe.'),
(4, 1, 7, 5, 'Amezing Product i\'ve purchased ever. Thanks Fashionflair...'),
(5, 1, 4, 3, 'Nice product!'),
(6, 2, 7, 1, '...');

-- --------------------------------------------------------

--
-- Table structure for table `sub_category`
--

CREATE TABLE `sub_category` (
  `sub_cat_id` int(5) NOT NULL,
  `cat_id` int(5) NOT NULL,
  `cat_name` varchar(50) NOT NULL,
  `cat_desc` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sub_category`
--

INSERT INTO `sub_category` (`sub_cat_id`, `cat_id`, `cat_name`, `cat_desc`) VALUES
(1, 1, 'Shirt', 'Versatile garment, suitable for formal or casual wear, offering a polished look with various patterns and fits available.\r\n'),
(2, 1, 'T-shirt', 'Casual essential, comfortable and easy-to-wear comes in a range of styles, colors, and designs for everyday attire.'),
(3, 1, 'Pants', 'Staple bottoms, offering versatility from formal trousers to casual chinos, tailored to fit different occasions and preferences.'),
(4, 2, 'Dress', 'Versatile garment, ranging from casual sundresses to elegant evening gowns, offering a wide variety of styles, lengths, and designs.'),
(5, 2, 'Kurta', 'Traditional attire, blending elegance and cultural heritage, perfect for both casual outings and formal gatherings.');

-- --------------------------------------------------------

--
-- Table structure for table `tracker`
--

CREATE TABLE `tracker` (
  `id` int(11) NOT NULL,
  `c_name` varchar(60) NOT NULL,
  `prod_name` varchar(60) NOT NULL,
  `qua_ntity` int(11) NOT NULL,
  `ord_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `user_address`
--

CREATE TABLE `user_address` (
  `AddressID` int(11) NOT NULL,
  `UserID` int(11) NOT NULL,
  `FirstName` varchar(50) NOT NULL,
  `LastName` varchar(50) NOT NULL,
  `Country` varchar(100) NOT NULL,
  `StreetAddress` varchar(255) NOT NULL,
  `City` varchar(100) NOT NULL,
  `state` varchar(100) NOT NULL,
  `PostalCode` varchar(20) NOT NULL,
  `PhoneNumber` varchar(20) NOT NULL,
  `Email` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_address`
--

INSERT INTO `user_address` (`AddressID`, `UserID`, `FirstName`, `LastName`, `Country`, `StreetAddress`, `City`, `state`, `PostalCode`, `PhoneNumber`, `Email`) VALUES
(1, 1, 'Alex', 'doe', 'india', 'Alex house ', 'Vadodara', 'Gujrat', '390014', '9988774411', 'thundergodff1996@gmail.com'),
(2, 1, 'Alex', 'doe', 'india', 'Alex house ', 'Vadodara', 'Gujrat', '390014', '9988774411', 'thundergodff1996@gmail.com'),
(3, 2, 'Alex', 'doe', 'india', 'Alex house ', 'Vadodara', 'Gujrat', '390014', '9988774411', 'thundergodff1996@gmail.com'),
(4, 1, 'Firstname', 'Lastname', 'india', 'House and street address', 'Vadodara', 'Gujrat', '390014', '95895858541', 'thundergodff1996@gmail.com'),
(5, 1, 'Firstname', 'Lastname', 'india', 'House and street address', 'Vadodara', 'Gujrat', '390014', '95895858541', 'thundergodff1996@gmail.com'),
(6, 1, 'Firstname', 'Lastname', 'india', 'House and street address', 'Vadodara', 'Gujrat', '390014', '95895858541', 'thundergodff1996@gmail.com'),
(7, 1, 'Firstname', 'Lastname', 'india', 'House and street address', 'Vadodara', 'Gujrat', '390014', '95895858541', 'thundergodff1996@gmail.com'),
(8, 1, 'Firstname', 'Lastname', 'india', 'House and street address', 'Vadodara', 'Gujrat', '390014', '95895858541', 'thundergodff1996@gmail.com'),
(9, 1, 'Firstname', 'Lastname', 'india', 'House and street address', 'Vadodara', 'Gujrat', '390014', '95895858541', 'thundergodff1996@gmail.com'),
(10, 1, 'Firstname', 'Lastname', 'india', 'House and street address', 'Vadodara', 'Gujrat', '390014', '95895858541', 'thundergodff1996@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `user_order`
--

CREATE TABLE `user_order` (
  `OrderID` int(11) NOT NULL,
  `UserID` int(11) NOT NULL,
  `AddressID` int(11) NOT NULL,
  `OrderDate` date NOT NULL DEFAULT current_timestamp(),
  `PaymentMethod` varchar(50) NOT NULL,
  `order_no` varchar(100) NOT NULL,
  `pro_id` int(5) NOT NULL,
  `qty` int(5) NOT NULL,
  `dv` int(5) DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_order`
--

INSERT INTO `user_order` (`OrderID`, `UserID`, `AddressID`, `OrderDate`, `PaymentMethod`, `order_no`, `pro_id`, `qty`, `dv`, `status`) VALUES
(4, 1, 4, '2024-04-17', 'Online', '10755', 7, 1, 300, 0),
(5, 1, 5, '2024-04-18', 'Online', '92403', 6, 1, 0, 0),
(6, 1, 6, '2024-04-24', 'Online', '78984', 6, 1, 0, 0),
(7, 1, 7, '2024-04-24', 'Online', '96844', 6, 1, 0, 0),
(8, 1, 8, '2024-04-24', 'Online', '70690', 6, 1, 0, 0),
(9, 1, 9, '2024-04-24', 'Online', '81794', 4, 1, 0, 0),
(10, 1, 10, '2024-04-24', 'Online', '14824', 1, 1, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `wishlist`
--

CREATE TABLE `wishlist` (
  `wish_id` int(5) NOT NULL,
  `u_id` int(5) NOT NULL,
  `prod_id` int(12) NOT NULL,
  `c_id` int(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `wishlist`
--

INSERT INTO `wishlist` (`wish_id`, `u_id`, `prod_id`, `c_id`) VALUES
(1, 1, 7, 2),
(2, 1, 6, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`a_id`);

--
-- Indexes for table `canceled_orders`
--
ALTER TABLE `canceled_orders`
  ADD PRIMARY KEY (`cancellation_id`);

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`cart_id`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`cat_id`);

--
-- Indexes for table `complain`
--
ALTER TABLE `complain`
  ADD PRIMARY KEY (`c_id`);

--
-- Indexes for table `contact_us`
--
ALTER TABLE `contact_us`
  ADD PRIMARY KEY (`con_id`);

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`customer_id`);

--
-- Indexes for table `delivery`
--
ALTER TABLE `delivery`
  ADD PRIMARY KEY (`o_id`);

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`f_id`);

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `offers`
--
ALTER TABLE `offers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `code` (`code`);

--
-- Indexes for table `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`pay_id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`prod_id`);

--
-- Indexes for table `review`
--
ALTER TABLE `review`
  ADD PRIMARY KEY (`rw_id`);

--
-- Indexes for table `sub_category`
--
ALTER TABLE `sub_category`
  ADD PRIMARY KEY (`sub_cat_id`);

--
-- Indexes for table `tracker`
--
ALTER TABLE `tracker`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_address`
--
ALTER TABLE `user_address`
  ADD PRIMARY KEY (`AddressID`);

--
-- Indexes for table `user_order`
--
ALTER TABLE `user_order`
  ADD PRIMARY KEY (`OrderID`);

--
-- Indexes for table `wishlist`
--
ALTER TABLE `wishlist`
  ADD PRIMARY KEY (`wish_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `a_id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `canceled_orders`
--
ALTER TABLE `canceled_orders`
  MODIFY `cancellation_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `cart_id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `cat_id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `complain`
--
ALTER TABLE `complain`
  MODIFY `c_id` int(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `contact_us`
--
ALTER TABLE `contact_us`
  MODIFY `con_id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `customer_id` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `delivery`
--
ALTER TABLE `delivery`
  MODIFY `o_id` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `f_id` int(15) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `id` int(123) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `offers`
--
ALTER TABLE `offers`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `payment`
--
ALTER TABLE `payment`
  MODIFY `pay_id` int(12) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `prod_id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `review`
--
ALTER TABLE `review`
  MODIFY `rw_id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `sub_category`
--
ALTER TABLE `sub_category`
  MODIFY `sub_cat_id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tracker`
--
ALTER TABLE `tracker`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `user_address`
--
ALTER TABLE `user_address`
  MODIFY `AddressID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `user_order`
--
ALTER TABLE `user_order`
  MODIFY `OrderID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `wishlist`
--
ALTER TABLE `wishlist`
  MODIFY `wish_id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
