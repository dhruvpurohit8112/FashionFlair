from flask import Flask, request, render_template, session, redirect, url_for, jsonify,render_template_string,flash, make_response
from flask_mail import Mail, Message
from werkzeug.utils import secure_filename
from flask_session import Session
from instamojo_wrapper import Instamojo
from fuzzywuzzy import fuzz
from random import *
import pymysql
import uuid
import os
import random

app = Flask(__name__)

app.config['SECRET_KEY'] ='bcaaztwsamthhctg'
app.config['MAIL_SERVER'] = 'smtp.gmail.com'
app.config['MAIL_PORT'] = 587
app.config['MAIL_USE_TLS'] = True  # Enable TLS for security
app.config['MAIL_USE_SSL'] = False  # Disable SSL
app.config['MAIL_USERNAME'] = "fashion.flairclothing@gmail.com"
app.config['MAIL_PASSWORD'] = "bcaaztwsamthhctg"

mail = Mail(app)

app.config["SESSION_PERMANENT"] = False
app.config["SESSION_TYPE"] = "filesystem"
Session(app)

conn = pymysql.connect(host='localhost', user='root', password='', db='fashionflair')

UPLOAD_FOLDER = 'static/upload/'

def generate_product_code():
    product_code = str(uuid.uuid4().hex)[:8] 
    return product_code

@app.route("/")
def home():
    user_id = session.get('customer_id')
    cursor = conn.cursor()
    query = """SELECT DISTINCT pt.prod_id, pt.prod_img, pt.prod_name, pt.prod_price, pt.prod_desc, c.status
           FROM product pt
           LEFT JOIN cart c ON pt.prod_id = c.prod_id AND c.customer_id = %s
           ORDER BY CASE WHEN c.status = 'paid' THEN 0 ELSE 1 END,
                    CASE WHEN c.prod_id IS NULL THEN 0 ELSE 1 END, 
                    pt.prod_id DESC
        """
    val = (user_id,)
    cursor.execute(query, val)
    products = cursor.fetchall()
    cursor.close()

    
    cursor = conn.cursor()
    query = "SELECT * FROM product"
    cursor.execute(query)
    allprod = cursor.fetchall()
    cursor.close()
    
    cursor = conn.cursor()
    query = "SELECT * FROM product ORDER BY prod_id DESC"
    cursor.execute(query)
    newaws = cursor.fetchall()
    cursor.close()
    
    cursor = conn.cursor()
    query = "SELECT * FROM offers"
    cursor.execute(query)
    coupons = cursor.fetchall()
    cursor.close()
    
    return render_template('/fashionflair/home.html', products=products,product=allprod,newaws=newaws,coupons=coupons)


@app.route("/login")
def login():
    return render_template('/fashionflair/login.html')

@app.route('/customer_login', methods=["POST"])
def customer_login():
    cursor = conn.cursor()
    c_email = request.form['email']
    c_pass = request.form['password']
    query = "SELECT * FROM customers WHERE customer_email = %s AND customer_pwd = %s"
    val = (c_email, c_pass)
    cursor.execute(query, val)
    account = cursor.fetchone() 
    if account:
        session["customer_id"] = account[0]
        session["name"] = account[1]
        session["customer_email"] = account[2]
        
        flash('Login successfully!', 'success')
        cursor.close()  # Close cursor here
        return redirect(url_for('home'))
    else:
        flash('Error: Please provide data.', 'error')
        cursor.close()  # Close cursor here
        return render_template('fashionflair/login.html')

@app.route("/reg_auth", methods=["GET", "POST"])
def reg_auth():
    if request.method == "POST":
        entered_otp = int(request.form["otp"])
        stored_otp = session.get("otp")
        if entered_otp == stored_otp:
            return redirect(url_for("login"))
        else:
            return render_template("fashionflair/reg_auth.html", msg="Invalid OTP. Please try again.")
    
@app.route('/forget_pass')
def forget_pass():
    return render_template('fashionflair/forgot-pass.html')

@app.route("/forgot",methods=['POST'])
def forgot():
    email = request.form['email']
    cursor = conn.cursor()        
    cursor.execute("SELECT * FROM customers WHERE customer_email = %s", (email,))
    result = cursor.fetchone()
    
    if result:
        pass1= result[3]
        msg = Message('Your Password', sender='fashion.flairclothing@gmail.com', recipients=[email])
        msg.body = "Your Password is " + pass1 + " .!!"
        mail.send(msg)
        msg = f"Password send to your email: {email}"
        return render_template("fashionflair/login.html", msg=msg)           
    else:
        return redirect(url_for('forget_pass'))

# Customer Logout
@app.route('/user_logout')
def customer_logout():
    session.pop('customer_id', None)
    session.pop('name', None)
    session.pop('customer_email', None)
    return redirect(url_for('home'))

@app.route("/register")
def registration():
    return render_template('/fashionflair/registration.html')

@app.route("/about-us")
def about_us():
    return render_template('/fashionflair/about-us.html')

@app.route("/contact-us")
def contact_us():
    return render_template('/fashionflair/contact-us.html')

from flask import request

@app.route("/all_products", methods=["GET", "POST"])
def all_products():
    # Get the sorting option from the form
    sort_by = request.args.get('sort_by', 'newness')

    cursor = conn.cursor()
    query = """SELECT p.*, COALESCE(AVG(r.rating), 0) AS avg_rating,
                      COUNT(r.rating) AS review_count
               FROM product p 
               LEFT JOIN review r ON p.prod_id = r.prod_id 
               GROUP BY p.prod_id 
               ORDER BY """

    # Adjust the SQL query based on the selected sorting option
    if sort_by == 'rating':
        query += "avg_rating DESC, "
    elif sort_by == 'popularity':
        query += "review_count DESC, "
    elif sort_by == 'price_low_high':
        query += "p.prod_price ASC, "
    elif sort_by == 'price_high_low':
        query += "p.prod_price DESC, "
    elif sort_by == 'name_z':
        query += "p.prod_name DESC, "

    query += "p.prod_id DESC"
    
    cursor.execute(query)
    products = cursor.fetchall()
    cursor.close()
    
    return render_template('fashionflair/all-products.html', product=products)

@app.route('/male-products')
def male_products():
    cursor = conn.cursor()
    user_id = session.get('customer_id')
    cat_id=1
    print(user_id)
    if user_id is not None:        
        query = """SELECT DISTINCT pt.prod_id, pt.prod_img, pt.prod_name, pt.prod_price, pt.prod_desc, c.status,pt.prod_code,pt.sub_cat_id,pt.cat_id FROM product pt LEFT JOIN user_order c ON pt.prod_id = c.pro_id AND c.UserID = %s and pt.cat_id=%s ORDER BY CASE WHEN c.status = 0 THEN 0 ELSE 1 END, CASE WHEN c.pro_id IS NULL THEN 0 ELSE 1 END, pt.prod_id DESC
            """
        val = (user_id,cat_id)
        cursor.execute(query, val)
        products1 = cursor.fetchall()
        cursor.close()
        print(products1)
        return render_template('fashionflair/all-products.html',product1=products1)
    else:
        query = "SELECT * FROM product WHERE cat_id = 1"
        cursor.execute(query)
        products = cursor.fetchall()
        cursor.close()
    return render_template('fashionflair/all-products.html', product=products)



@app.route('/female-products')
def female_products():
    # Get the filter criteria from the URL parameter
    sort_by = request.args.get('sort_by', None)

    cursor = conn.cursor()
    query = "SELECT * FROM product WHERE cat_id = 2"

    # Adjust the query based on the sort criteria, if provided
    if sort_by:
        if sort_by == 'rating':
            query += " ORDER BY average_rating DESC"  # Assuming 'average_rating' is the column name for rating
        elif sort_by == 'price_low_high':
            query += " ORDER BY prod_price ASC"
        elif sort_by == 'price_high_low':
            query += " ORDER BY prod_price DESC"
        elif sort_by == 'name_z':
            query += " ORDER BY prod_name DESC"

    cursor.execute(query)
    products = cursor.fetchall()
    cursor.close()

    return render_template('fashionflair/all-products.html', product=products)

    
@app.route("/cart")
def cart(): 
    customer_id = session.get('customer_id')
    if customer_id is None:
        return redirect(url_for('login'))

    cursor = conn.cursor()
    query = "SELECT a.*, b.* FROM product AS a, cart AS b WHERE a.prod_id = b.prod_id AND b.customer_id = %s AND status = 'unpaid'" 
    val = (customer_id,)
    cursor.execute(query, val)
    items = cursor.fetchall()
    
    if not items:  # If cart is empty
        return render_template('/fashionflair/empty_cart.html')

    total = sum(item[5] * item[13] for item in items)
    return render_template('/fashionflair/cart.html', items=items, total=total)

@app.route("/empty_cart")
def empty_cart():
    return render_template('/fashionflair/empty_cart.html')

@app.route("/checkout")
def checkout(): 
    dv = int(request.args.get('dv'))
    customer_id = session.get('customer_id')
    if customer_id is None:
        return redirect(url_for('login'))

    cursor = conn.cursor()
    query = "SELECT a.*, b.* FROM product AS a, cart AS b WHERE a.prod_id = b.prod_id AND b.customer_id = %s AND b.status='unpaid'" 
    val = (customer_id,)
    cursor.execute(query, val)
    items = cursor.fetchall()
    
    if not items:  # If cart is empty
        return render_template('/fashionflair/home.html')

    total = sum(item[5] * item[13] for item in items)
    return render_template('/fashionflair/checkout.html', items=items, total=total,dv=dv)

@app.route("/plusqty/<int:cart_id>/<int:qty>",methods=["GET"])
def plusqty(cart_id,qty):
    qty = qty+1
    cursor = conn.cursor()
    query = "UPDATE cart SET qty = %s WHERE cart_id = %s"
    val = (qty,cart_id)
    cursor.execute(query, val)
    cursor.close()
    conn.commit()
    return redirect(url_for('cart'))

@app.route("/minusqty/<int:cart_id>/<int:qty>",methods=["GET"])
def minusqty(cart_id,qty):
    if (qty > 1):
        qty = qty-1
    else:
        qty = 1
        
    cursor = conn.cursor()
    query = "UPDATE cart SET qty = %s WHERE cart_id = %s"
    val = (qty,cart_id)
    cursor.execute(query, val)
    conn.commit()
    cursor.close()
    return redirect(url_for('cart'))

@app.route("/remove_cart_item/<int:cart_id>", methods=["GET"])
def remove_cart_item(cart_id=None):
    cursor = conn.cursor()
    if cart_id is not None:
        query = "DELETE FROM cart WHERE cart.cart_id = %s"
        val = (cart_id)
        cursor.execute(query, val)
        conn.commit()
        cursor.close()
        return redirect(url_for('cart'))

@app.route("/wishlist")
def wishlist():
    if 'customer_id' not in session:
        return redirect(url_for("login"))
    customer_id = session['customer_id']
    cursor = conn.cursor()
    query = "SELECT a.*,b.* FROM product as a,wishlist as b where a.prod_id = b.prod_id and b.u_id = %s"
    val = (customer_id)
    cursor.execute(query,val)
    wishlist = cursor.fetchall()
    return render_template('fashionflair/wishlist.html', wishes=wishlist)

@app.route("/remove_wish/<int:wish_id>", methods=["GET"])
def remove_wish(wish_id=None):
    cursor = conn.cursor()
    if wish_id is not None:
        query = "DELETE FROM wishlist WHERE wishlist.wish_id = %s"
        val = (wish_id)
        cursor.execute(query, val)
        conn.commit()
        cursor.close()
        referrer = request.headers.get("Referer")
        if referrer:
        # If referrer exists, redirect back to it
            return redirect(referrer)
        else:
        # If referrer is not available, redirect to a default page
            return redirect('/')

# Popup/Slidebar Cart and wishlist data detials 
@app.route("/fetch_wishlist", methods=['POST'])
def fetch_wishlist():
    customer_id = session['customer_id']
    cursor = conn.cursor()
    query = "SELECT a.prod_id, a.prod_name, a.prod_code, a.prod_price, a. prod_desc, a.prod_img, a.cat_id, b.* FROM product as a,wishlist as b where a.prod_id = b.prod_id and b.u_id = %s"
    val = (customer_id)
    cursor.execute(query,val)    
    wishlist = cursor.fetchall()    
    cursor.close()    
    return jsonify({'wishlist1': wishlist})

@app.route("/fetch_cart", methods=['POST'])
def fetch_cart():
    customer_id = session['customer_id']      
    cursor = conn.cursor()  
    query = "SELECT a.prod_id, a.prod_name, a.prod_code, a.prod_price, a. prod_desc, a.prod_img, a.cat_id, b.* FROM product as a,cart as b where a.prod_id = b.prod_id and b.customer_id = %s AND status = 'unpaid'"
    val = (customer_id)
    cursor.execute(query,val)
    conn.commit()
    cartdata = cursor.fetchall()
    print(cartdata)
    cursor.close()    
    return jsonify({'wishlist': cartdata})

@app.route("/detail/<int:prod_id>", methods=["GET"])
def detail(prod_id):
        cursor = conn.cursor()
        query = "SELECT * FROM product WHERE prod_id = %s"
        val = (prod_id)
        cursor.execute(query, val)
        product = cursor.fetchone()
        cursor.close()
        
        cursor = conn.cursor()
        query = "SELECT customers.name, review.* FROM customers INNER JOIN review ON customers.customer_id = review.user_id WHERE review.prod_id = %s"
        val = (prod_id)
        cursor.execute(query,val)
        reviews = cursor.fetchall()
        cursor.close()
        
        cursor = conn.cursor()
        query = "SELECT COUNT(*) AS event_review_count FROM review WHERE prod_id = %s"
        cursor.execute(query, (prod_id,))
        count = cursor.fetchone()
        cursor.close()
        event_review_count = count[0]
        
        cursor = conn.cursor()
        query = "SELECT sub_cat_id FROM product WHERE prod_id = %s"
        val = (prod_id)
        cursor.execute(query, val)
        sub_cat_id = cursor.fetchone()[0]
        cursor.close()
        cursor = conn.cursor()
        query = "SELECT * FROM product WHERE sub_cat_id = %s"
        val = (sub_cat_id)
        cursor.execute(query,val)
        related_products = cursor.fetchall()
        cursor.close()
            
        return render_template("fashionflair/product-details.html", pdata=product,review=reviews,count=event_review_count,related_products=related_products)

# Customer Registration
@app.route('/add_user',methods=['POST'])
def add_user():
    cursor = conn.cursor()
    uname = request.form['name']
    email = request.form['email']
    gender = request.form['gender']
    address = request.form['address']
    contact = request.form['contact']
    password = request.form['password']

    query = "INSERT INTO customers(name,customer_email,customer_pwd,gender,contact,address)VALUES(%s,%s,%s,%s,%s,%s)"
    val = (uname,email,password,gender,contact,address)
    cursor.execute(query,val)
    conn.commit()
    cursor.close()

    if(cursor.rowcount==1):
        otp = randint(1000, 9999)
        session["otp"] = otp
        # Send OTP to user's email
        msg = Message('Your OTP', sender='fashion.flairclothing@gmail.com', recipients=[email])
        msg.html = render_template('/fashionflair/otp.html',otp=otp)
        mail.send(msg)
        return render_template('fashionflair/reg_auth.html')
    
# Product Serach
@app.route("/search", methods=["GET", "POST"])
def search():
    if request.method == "POST":
        # Get the search query from the form
        search_query = request.form.get("search_query")

        # Perform the search logic here
        cursor = conn.cursor()
        query = "SELECT * FROM product WHERE prod_name LIKE %s OR prod_desc LIKE %s"
        cursor.execute(query, (f"%{search_query}%", f"%{search_query}%"))
        search_results = cursor.fetchall()

        # Render the search results template
        return render_template("fashionflair/search.html", search_query=search_query, search_results=search_results)
    else:
        # If it's a GET request, redirect to the home page
        return redirect(url_for("home"))

# Add to cart & wishlist.
@app.route("/add2cart", methods=["POST"])
def add_to_cart():
    if 'customer_id' not in session:
        return redirect(url_for('login'))
    
    customer_id = session['customer_id']
    prod_id = request.form['prod_id']
    prod_qty = int(request.form['qty'])
    
    cursor = conn.cursor()

    if request.method == 'POST':
        if 'add_to_cart':
            query = "SELECT * FROM cart WHERE customer_id = %s AND prod_id = %s AND status ='unpaid'"
            val = (customer_id, prod_id)
            cursor.execute(query, val)
            existing_item = cursor.fetchone()

            if existing_item:
                new_qty = existing_item[3] + qty
                query = "UPDATE cart SET qty = %s WHERE customer_id = %s AND prod_id = %s"
                val = (new_qty, customer_id, prod_id)
                cursor.execute(query, val)
                return redirect(url_for("cart"))
            else:
                # If the item doesn't exist, add it to the cart
                query = "INSERT INTO cart (customer_id, prod_id, qty) VALUES (%s, %s, %s)"
                val = (customer_id, prod_id, prod_qty)
                cursor.execute(query, val)
                return redirect(url_for("cart"))
                
        elif 'add_to_wishlist' in request.form:
            query = "INSERT INTO wishlist (customer_id, prod_id, qty) VALUES (%s, %s, %s)"
            val = (customer_id, prod_id, qty)
            cursor.execute(query, val)
            conn.commit()
            return redirect(url_for("wishlist"))
    cursor.close() 
    return redirect(url_for("home"))

@app.route("/cartfrm_home/<int:prod_id>/<int:cat_id>",methods=["GET"])
def cartfrm_home(prod_id,cat_id):
    if 'customer_id' not in session:
        return redirect(url_for('login'))
    customer_id = session['customer_id']
    cursor = conn.cursor()
    query = "SELECT * FROM cart WHERE customer_id = %s AND prod_id = %s  AND status = 'unpaid'"
    val = (customer_id, prod_id)
    cursor.execute(query, val)
    existing_item = cursor.fetchone()
    if existing_item:
        new_qty = existing_item[3] + 1
        query = "UPDATE cart SET qty = %s WHERE customer_id = %s AND prod_id = %s"
        val = (new_qty, customer_id, prod_id)
        cursor.execute(query, val)
        conn.commit()
        return redirect(url_for("cart"))
    else:
        qty = 1
        cursor = conn.cursor()
        query = "INSERT INTO cart (customer_id, prod_id, qty) VALUES (%s, %s, %s)"
        val = (customer_id, prod_id, qty)
        cursor.execute(query, val)
        conn.commit()
        cursor.close()
        return redirect(url_for("cart"))
    
@app.route("/wishtocart/<int:prod_id>/<int:wish_id>",methods=["GET"])
def wishtocart(prod_id,wish_id):
    if 'customer_id' not in session:
        return redirect(url_for('login'))
    customer_id = session['customer_id']
    cursor = conn.cursor()
    query = "SELECT * FROM cart WHERE customer_id = %s AND prod_id = %s AND status = 'unpaid'"
    val = (customer_id, prod_id)
    cursor.execute(query, val)
    existing_item = cursor.fetchone()
    if existing_item:
        new_qty = existing_item[3] + 1
        query = "UPDATE cart SET qty = %s WHERE customer_id = %s AND prod_id = %s"
        val = (new_qty, customer_id, prod_id)
        cursor.execute(query, val)
    else:
        qty = 1
        cursor = conn.cursor()
        query = "INSERT INTO cart (customer_id, prod_id, qty) VALUES (%s, %s, %s)"
        val = (customer_id, prod_id, qty)
        cursor.execute(query, val)
    
    query = "DELETE FROM wishlist WHERE u_id = %s AND wish_id = %s"
    val = (customer_id,wish_id)
    cursor.execute(query,val)
    conn.commit()
    cursor.close()
    return redirect(url_for("cart"))  
    
@app.route("/wishfrm_home/<int:prod_id>/<int:cat_id>",methods=["GET"])
def wishfrm_home(prod_id,cat_id):
    if 'customer_id' not in session:
        return redirect(url_for('login'))
    customer_id = session['customer_id']
    cursor = conn.cursor()
    query = "INSERT INTO wishlist (u_id, prod_id, c_id) VALUES (%s, %s, %s)"
    val = (customer_id, prod_id, cat_id)
    cursor.execute(query, val)
    conn.commit()
    return redirect(url_for("wishlist"))
    
@app.route("/team_contact", methods=["POST"])
def team_contact():
    try:
        name = request.form['name']
        email = request.form['email']
        subject = request.form['subject']
        message = request.form['message']

        # Assuming 'conn' is a valid database connection
        cursor = conn.cursor()
        query = "INSERT INTO contact_us (name, email, subject, message) VALUES (%s, %s, %s, %s)"
        val = (name, email, subject, message)
        cursor.execute(query, val)
        conn.commit()
        cursor.close()
        
        # Redirect to the home page after successful submission
        return redirect(url_for('home'))

    except Exception as e:
        # Log the error or handle it appropriately
        print("Error:", e)
        # Redirect to an error page or display an error message
        return "An error occurred while processing your request."
    
# Admin Side Code
# Admin login 
@app.route('/admin_info')
def admin_info():
    cursor = conn.cursor()
    query = "SELECT a_name, profile_pic FROM admin"
    cursor.execute(query)
    admin_data = cursor.fetchone()  # Fetch the first row of the result set
    if admin_data:  # Check if data is fetched successfully
        admin_name = admin_data[0]  # Assuming admin name is stored at index 0
        admin_image_url = admin_data[1]  # Assuming admin image URL is stored at index 1
        print("Admin Name:", admin_name)
        print("Admin Image URL:", admin_image_url)
        response = jsonify({'name': admin_name, 'image_url': admin_image_url})
        # Set cache-related headers to prevent caching
        response.headers['Cache-Control'] = 'no-cache, no-store, must-revalidate'
        response.headers['Pragma'] = 'no-cache'
        response.headers['Expires'] = '0'
        return response
    else:
        return jsonify({'error': 'No admin data found'})

        
@app.route("/admin/admin_login", methods=["POST"])
def admin_login():
    cursor = conn.cursor()
    try:
        a_email = request.form['email']
        a_pass = request.form['password']
        query = "SELECT * FROM admin WHERE a_email = %s AND a_pwd = %s"
        val = (a_email, a_pass)
        cursor.execute(query, val)
        account = cursor.fetchone()

        if account:
            session['a_id'] = account[0]
            session['a_name'] = account[1]
            session['a_email'] = account[2]

            msg = 'Logged in successfully !'
            return redirect(url_for('dashboard',msg=msg))
        else:
            msg = 'Incorrect username / password !'
            return render_template('/admin/admin-login.html', msg=msg)
    finally:
        cursor.close()

@app.route('/admin_logout')
def admin_logout():
    session.pop('a_id', None) 
    session.pop('a_name', None) 
    session.pop('a_email', None)
    return redirect(url_for('home'))

@app.route("/admin/layout")
def admin_layout():
    return render_template("/admin/layout.html")

@app.route("/admin")
def dashboard():
    if 'a_id' not in session:
        return render_template("/admin/admin-login.html")
    else:
        
        msg = request.args.get('msg')
        return render_template("/admin/dashboard.html", current_page="dashboard",msg=msg)

@app.route("/admin/profile")
def profile():
    if 'a_id' not in session:
        return render_template("/admin/admin-login.html")
    else:
        cursor = conn.cursor()
        try:
            query = "SELECT * FROM admin"
            cursor.execute(query)
            a_details = cursor.fetchall()
            return render_template("/admin/profile.html", current_page="profile", p_details=a_details)
        finally:
            cursor.close()

@app.route("/admin/product_category")
def product_category():
    if 'a_id' not in session:
        return render_template("/admin/admin-login.html")
    else:
        cursor = conn.cursor()
        try:
            query = "SELECT * FROM category"
            cursor.execute(query)
            categories = cursor.fetchall()
            return render_template("/admin/product-category.html", current_page="product_category", all_category=categories)
        finally:
            cursor.close()

@app.route("/admin/product_sub_category")
def product_sub_category():
    if 'a_id' not in session:
        return render_template("/admin/admin-login.html")
    else:
        cursor = conn.cursor()
        try:
            query = "SELECT * FROM sub_category"
            cursor.execute(query)
            categories = cursor.fetchall()
            return render_template("/admin/sub-product-category.html", current_page="product_category", all_category=categories)
        finally:
            cursor.close()

@app.route("/admin/sub_product_category")
def sub_product_category():
    if 'a_id' not in session:
        return render_template("/admin/admin-login.html")
    else:
        cursor = conn.cursor()
        try:
            query = "SELECT * FROM category"
            cursor.execute(query)
            pcats = cursor.fetchall()
            
            query = "SELECT * FROM sub_category"
            cursor.execute(query) 
            categories = cursor.fetchall()
            return render_template("/admin/sub-product-category.html", current_page="product_category", all_category=categories, area=pcats)
        finally:
            cursor.close()

@app.route("/admin/add_product")
def add_product():
    if 'a_id' not in session:
        return render_template("/admin/admin-login.html")
    else:
        cursor = conn.cursor()
        try:
            query_category = "SELECT * FROM category"
            cursor.execute(query_category) 
            categories = cursor.fetchall()

            query_subcategory = "SELECT * FROM sub_category WHERE cat_id = %s"
            subcategories = []
            for category in categories:
                cursor.execute(query_subcategory, (category[0],))
                subcategories.append(cursor.fetchall())
        finally:
            cursor.close()
        product_code = generate_product_code()
        return render_template("/admin/add_product.html", current_page="add_product", product_code=product_code, categories=categories, subcategories=subcategories)

@app.route("/get_subcategories/<int:category_id>")
def get_subcategories(category_id):
    cursor = conn.cursor()
    try:
        query = "SELECT sub_cat_id, cat_name FROM sub_category WHERE cat_id = %s"
        cursor.execute(query, (category_id,))
        subcategories = cursor.fetchall()
    finally:
        cursor.close()

    subcategory_dict = {subcategory[0]: subcategory[1] for subcategory in subcategories}
    return jsonify(subcategory_dict)

@app.route("/admin/products")
def products():
    if 'a_id' not in session:
        return render_template("/admin/admin-login.html")
    else:
        cursor = conn.cursor()
        try:
            query = "SELECT * FROM product"
            cursor.execute(query) 
            product = cursor.fetchall() 

            query = "SELECT * FROM category"
            cursor.execute(query) 
            account = cursor.fetchall()
        finally:
            cursor.close()
        return render_template("/admin/products.html", current_page="products",all_products=product,area=account)

# Admin Add new category
@app.route("/product_category", methods=['POST'])
def add_new_category():
    cursor = conn.cursor()
    try:
        cat_name = request.form['cname']
        cat_desc = request.form['cdesc']
        
        query = "INSERT INTO category(cat_name,cat_desc)VALUES(%s,%s)"
        val = (cat_name,cat_desc)
        cursor.execute(query,val)
        conn.commit()
        return redirect(url_for('product_category'))
    finally:
        cursor.close()

@app.route("/product_sub_category", methods=['POST'])
def add_sub_category():
    cursor = conn.cursor()
    try:
        cat_id = request.form['category']
        cat_name = request.form['cname']
        cat_desc = request.form['cdesc']
        
        query1 = "INSERT INTO sub_category(cat_id, cat_name, cat_desc) VALUES (%s, %s, %s)"
        val1 = (cat_id, cat_name, cat_desc)
        cursor.execute(query1, val1)
        conn.commit()
        return redirect(url_for('sub_product_category'))
    finally:
        cursor.close()

# Admin Edit/Update category
@app.route("/update_category", methods=['POST'])
def update_category():
    cursor = conn.cursor()
    try:
        catn_name = request.form['cn_name']
        catn_desc = request.form['cn_desc']
        ucat_id = request.form['cat_id']
        
        query = "UPDATE category SET cat_name = %s, cat_desc = %s WHERE cat_id = %s"
        val = (catn_name, catn_desc, ucat_id)
        cursor.execute(query, val)
        conn.commit()
        return redirect(url_for('product_category'))
    finally:
        cursor.close()

@app.route("/update_sub_category", methods=['POST'])
def update_sub_category():
    cursor = conn.cursor()
    try:
        catn_name = request.form['cn_name']
        catn_desc = request.form['cn_desc']
        ucat_id = request.form['cat_id']
        main_cat = request.form['category']

        query = "UPDATE sub_category SET cat_id = %s, cat_name = %s, cat_desc = %s WHERE sub_cat_id = %s"
        val = (main_cat, catn_name, catn_desc, ucat_id)
        cursor.execute(query, val)
        conn.commit()
        return redirect(url_for('sub_product_category'))
    finally:
        cursor.close()

# admin Delete category
@app.route("/delete_category", methods=['POST'])
def delete_category():
    cursor = conn.cursor()
    try:
        dcat_id = request.form['cat_id']

        query = "DELETE FROM category WHERE cat_id = %s"
        val = (dcat_id,)
        cursor.execute(query, val)
        conn.commit()
        return redirect(url_for('product_category'))
    finally:
        cursor.close()

@app.route("/delete_sub_category", methods=['POST'])
def delete_sub_category():
    cursor = conn.cursor()
    try:
        dcat_id = request.form['cat_id']

        query = "DELETE FROM sub_category WHERE sub_cat_id = %s"
        val = (dcat_id,)
        cursor.execute(query, val)
        conn.commit()
        return redirect(url_for('sub_product_category'))
    finally:
        cursor.close()

# Admin Add new Product
@app.route("/add_product", methods=['POST'])
def add_new_product():
    cursor = conn.cursor()
    try:
        pname = request.form['name']
        pcode = request.form['code']
        pprice = request.form['price']
        pdesc = request.form['description']
        pcat = request.form['category']
        psubcat = request.form['subcategory']

        prod_img=request.files['image']
        filename=secure_filename(prod_img.filename)
        prod_img.save(os.path.join(UPLOAD_FOLDER,filename))
        path=os.path.join(UPLOAD_FOLDER,filename)

        query = "INSERT INTO product(prod_name,prod_code,prod_price,prod_desc,prod_img,cat_id,sub_cat_id)VALUES(%s,%s,%s,%s,%s,%s,%s)"
        val = (pname,pcode,pprice,pdesc,path,pcat,psubcat)
        cursor.execute(query,val)
        conn.commit()
        return render_template("/admin/dashboard.html")
    finally:
        cursor.close()

# Admin side Edit/Update Product details
@app.route("/update_product", methods=['POST'])
def update_product():
    cursor = conn.cursor()
    try:
        prod_id = request.form['p_id']
        pn_name = request.form['pn_name']
        pn_price = request.form['pn_price']
        pn_cat = request.form['pn_cat']
        pn_desc = request.form['pn_desc']
        pn_image=request.files['pn_image']
        
        if pn_image:  
            filename=secure_filename(pn_image.filename)
            pn_image.save(os.path.join(UPLOAD_FOLDER,filename))
            path=os.path.join(UPLOAD_FOLDER,filename)
            query = "UPDATE product SET prod_name = %s, prod_price = %s, prod_desc = %s, prod_img = %s, cat_id = %s  WHERE prod_id = %s"
            val = (pn_name, pn_price, pn_desc, path, pn_cat ,prod_id)
        else:
            query = "UPDATE product SET prod_name = %s, prod_price = %s, prod_desc = %s, cat_id = %s WHERE prod_id = %s"
            val = (pn_name, pn_price, pn_desc, pn_cat, prod_id)

        cursor.execute(query, val)
        conn.commit()
        return render_template("/admin/dashboard.html")
    finally:
        cursor.close()

# Admin side Delete product 
@app.route("/delete_product", methods=['POST'])
def delete_product():
    cursor = conn.cursor()
    try:
        dp_id = request.form['p_id']

        query = "DELETE FROM product WHERE prod_id = %s"
        val = (dp_id,)
        cursor.execute(query, val)
        conn.commit()
        return render_template("/admin/dashboard.html")
    finally:
        cursor.close()

# Admin profile update
@app.route("/admin_profile", methods=['POST'])
def admin_profile():
    cursor = conn.cursor()
    try:
        ua_id = request.form['a_id']
        a_name = request.form['name']
        a_email = request.form['email']
        a_org = request.form['organization']
        a_contact = request.form['contact']
        a_address = request.form['address']
        # Access file data using request.files
        a_image = request.files['image']
        if a_image:  # Check if a file was uploaded

            filename = secure_filename(a_image.filename)
            a_image.save(os.path.join(UPLOAD_FOLDER, filename))
            image_path = os.path.join(UPLOAD_FOLDER, filename)
            query = "UPDATE admin SET a_name = %s, a_email = %s, org = %s, con_no = %s, address = %s, profile_pic = %s WHERE a_id = %s"
            val = (a_name, a_email, a_org, a_contact, a_address, image_path, ua_id)
        else:
            query = "UPDATE admin SET a_name = %s, a_email = %s, org = %s, con_no = %s, address = %s WHERE a_id = %s"
            val = (a_name, a_email, a_org, a_contact, a_address, ua_id)
        
        cursor.execute(query, val)
        conn.commit()
        return render_template("/admin/dashboard.html")
    finally:
        cursor.close()




api = Instamojo(api_key="test_e3e8ea4ace21b8e7f2942ce444a",
                auth_token="test_797d39c4dd252b88ca6ed097c48", endpoint="https://test.instamojo.com/api/1.1/")
@app.route("/confirm_order", methods=['POST'])
def confirm_order():
    cursor = conn.cursor()  
    tran_id = random.randint(10000,99999)
    tid = str(tran_id)  
    user_id = session.get('customer_id')
    total_amount = request.form['total_amount']
    size = request.form['size']
    dv = request.form['dv']
    payment_method = request.form['payment_method']            
    first_name = request.form['first_name']
    last_name = request.form['last_name']
    country = request.form['country']
    street_address = request.form['street_address']
    city = request.form['city']
    state_province = request.form['state_province']
    postal_code = request.form['postal_code']
    phone_number = request.form['phone_number']
    email = request.form['email']
    order_note = request.form['order_note']
    redirect_url = "http://127.0.0.1:5000/callback"
    complete_url = redirect_url + "?order_id=" + tid + "&size=" + size
    response1 = api.payment_request_create(
        amount=total_amount,
        purpose='Fashion & Flair',
        send_email=True,
        email=email,
        buyer_name=first_name,
        redirect_url=complete_url
    )  
    if response1.get('success'):
        order_details_message = f"Order Details:\n\n"
        order_details_message += f"Total Amount: ₹{int(total_amount) + int(dv)}\n"
        order_details_message += f"Paid Amount: ₹{total_amount}\n"
        order_details_message += f"Discount Amount: ₹{dv}\n"
        order_details_message += f"Payment Method: {payment_method}\n\n"
        order_details_message += f"Shipping Address:\n"
        order_details_message += f"Name: {first_name} {last_name}\n"
        order_details_message += f"Address: {street_address}, {city}, {state_province}, {postal_code}, {country}\n"
        order_details_message += f"Phone Number: {phone_number}\n"
        order_details_message += f"Email: {email}\n"
        order_details_message += f"Product size: {size}\n\n"
        order_details_message += f"Order Note: {order_note}\n"
                
        # Send order confirmation email to the customer
        msg = Message('Order Confirmation', sender='fashion.flairclothing@gmail.com', recipients=[email])
        msg.body = 'Your order has been confirmed.\n\n' + order_details_message
        mail.send(msg)
        
        # Send notification email to the admin
        admin_email = 'fashion.flairclothing@gmail.com'  # Replace with the actual admin email
        admin_msg = Message('New Order Notification', sender='fashion.flairclothing@gmail.com', recipients=[admin_email])
        admin_msg.body = 'A new order has been placed.\n\n' + order_details_message
        mail.send(admin_msg)
        
        address_query = """INSERT INTO user_address 
                                    (UserID, FirstName, LastName, Country, StreetAddress, City, state, PostalCode, PhoneNumber, Email) 
                                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)"""
        val = (user_id, first_name, last_name, country, street_address, city, state_province, postal_code, phone_number, email)
        cursor.execute(address_query, val)
        address_id = cursor.lastrowid
        query = "SELECT * FROM cart WHERE customer_id = %s AND status='unpaid'"
        val = (user_id,)
        cursor.execute(query, val) 
        account = cursor.fetchall()
        print(account)
        for x in account:
            proid = x[-3]
            qty = x[-2]
            oid = tran_id
            order_query = """INSERT INTO user_order 
                                (UserID, AddressID,  PaymentMethod, order_no,pro_id,qty,dv) 
                                VALUES (%s, %s, %s, %s, %s,%s,%s)"""
            cursor.execute(order_query, (user_id, address_id, payment_method, oid,proid,qty,dv))

        delete_cart_query = "UPDATE cart SET status = 'paid' WHERE customer_id = %s"
        cursor.execute(delete_cart_query, (user_id,))
        conn.commit()
        cursor.close()
        return redirect(response1['payment_request']['longurl'])
                
@app.route("/callback")
def callback():
    order_id = request.args.get('order_id')
    size = request.args.get('size')

    user_id = session.get('customer_id')
    cursor = conn.cursor()
    query = "SELECT a.*, b.* FROM user_order as a, product as b WHERE a.pro_id = b.prod_id AND a.UserID = %s AND a.order_no = %s" 
    val = (user_id, order_id)
    cursor.execute(query, val) 
    account = cursor.fetchall()

    # Check if the account tuple is empty
    if not account:
        return "No records found."

    total = sum([row[7] * row[15] for row in account])
    st = 1
    invno = account[0][5]
    odate = account[0][3]
    dv = account[0][8]
    conn.commit() 
    cursor.close()

    return render_template("fashionflair/invoice.html", area=account, total=total, s=st, tid=invno, d=odate, dv=dv,size=size) 
  

@app.route('/admin/orders')
def orders():
    cursor = conn.cursor()
    try:
        query = "SELECT DISTINCT uo.order_no,uo.OrderDate,c.name  FROM user_order uo JOIN customers c ON uo.UserID = c.customer_id"
        cursor.execute(query)
        orders = cursor.fetchall()
        print(orders)
        return render_template('admin/orders.html', orders=orders)
    finally:
        cursor.close()

@app.route('/admin/customers')
def customers():
    cursor = conn.cursor()
    try:
        query = "SELECT * FROM customers"
        cursor.execute(query)
        customers = cursor.fetchall()
        return render_template('admin/customers.html', data=customers)
    finally:
        cursor.close()
        
@app.route('/admin/offers')
def offers():
    cursor = conn.cursor()
    try:
        query = "SELECT * FROM offers"
        cursor.execute(query)
        all_offers = cursor.fetchall()
        return render_template('admin/offers.html', offers=all_offers, current_page="offers")
    finally:
        cursor.close()
        
        
@app.route('/admin/add_offer', methods=['GET', 'POST'])
def add_offer():
    if request.method == 'POST':
        title = request.form['title']
        code = request.form['code']
        description = request.form['description']
        discount_value = request.form['discount_value']
        date = request.form['date']
        
        cursor = conn.cursor()
        try:
            query = "INSERT INTO offers (title, code, description, discount_value, end_date) VALUES (%s, %s, %s, %s,%s)"
            cursor.execute(query, (title, code, description, discount_value, date))
            conn.commit()
            return redirect(url_for('offers'))
        except Exception as e:
            conn.rollback()
            msg = "Failed to add offer: " + str(e)
            return render_template('admin/offers.html', msg=msg)
        finally:
            cursor.close()
    else:
        return render_template('admin/add_offer.html')

@app.route('/admin/edit_offer', methods=['POST'])
def edit_offer():
    if request.method == 'POST':
        try:
            offer_id = request.form['o_id']
            title = request.form['title']
            code = request.form['code']
            description = request.form['description']
            discount_value = request.form['discount_value']
            date = request.form['date']

            cursor = conn.cursor()
            query = "UPDATE offers SET title = %s, code = %s, description = %s, discount_value = %s, end_date = %s WHERE id = %s"
            cursor.execute(query, (title, code, description, discount_value, date, offer_id))
            conn.commit()
            cursor.close()
            
            flash('Offer updated successfully', 'success')  # Flash success message

            return redirect(url_for('offers'))
        except Exception as e:
            logging.error("Error occurred while updating offer: %s", e)
            conn.rollback()
            msg = "Failed to update offer: " + str(e)
            return render_template('admin/offers.html', msg=msg)

@app.route('/admin/delete_offer', methods=['POST'])
def delete_offer():
    if request.method == 'POST':
        offer_id = request.form['o_id']
        
        cursor = conn.cursor()
        try:
            query = "DELETE FROM offers WHERE id = %s"
            cursor.execute(query, (offer_id,))
            conn.commit()
            return redirect(url_for('offers'))
        except Exception as e:
            conn.rollback()
            msg = "Failed to delete offer: " + str(e)
            return render_template('admin/offers.html', msg=msg)
        finally:
            cursor.close()

@app.route('/apply_coupon', methods=['POST'])
def apply_coupon():
    if request.method == 'POST':
        coupon_code = request.form['coupon_code']
        total_price = float(request.form['total_price'])        
        cursor = conn.cursor()          
        coupon_offer_query = "SELECT * FROM offers WHERE code = %s"
        cursor.execute(coupon_offer_query, (coupon_code,))        
        coupon_offer = cursor.fetchone()          
        if coupon_offer:            
            dv=coupon_offer[-3]           
            coupon_applied = True
        else:
            dv=0
            coupon_applied = False
        
        cursor.close()  
        response = {
            "dv": dv,
            "coupon_applied": coupon_applied
        }
        return jsonify(response)
        


@app.route('/myorders')
def myorders():
    cursor = conn.cursor()
    user_id = session.get('customer_id')
    query = "SELECT distinct DISTINCT order_no, OrderDate, UserID, pro_id,status FROM user_order where UserID=%s"
    val=(user_id)

    cursor.execute(query,val)
    all_orders = cursor.fetchall()
    # print(all_orders)
    cursor.close()
    msg = request.args.get('msg')
    return render_template("fashionflair/myorders.html",items=all_orders,msg=msg)

@app.route('/viewmyorders/<int:oid>',methods=['GET'])
def viewmyorders(oid):
    cursor = conn.cursor()
    oid = oid
    user_id = session.get('customer_id')
   
    query = "SELECT a.*, b.* FROM user_order as a, product as b WHERE a.pro_id = b.prod_id AND a.UserID = %s AND a.order_no = %s" 
    val1 = (user_id, oid)
    cursor.execute(query, val1) 
    account = cursor.fetchall()
    total = sum([account[7] * account[15] for account in account])
    st = 1
    invno=account[0][5]
    odate=account[0][3]
    dv=account[0][8]
    conn.commit() 
    cursor.close()
    return render_template("fashionflair/invoice.html",area=account,total=total,s=st,tid=invno,d=odate,dv=dv) 



@app.route('/admin_order', methods=['POST'])
def admin_order():
    cursor = conn.cursor()
    estid = request.form['orderid']     
    val = (estid)
    query = "SELECT a.OrderID ,a.UserID,a.AddressID,a.PaymentMethod,a.order_no,a.pro_id,a.qty,a.dv, b.prod_id ,b.prod_name,b.prod_code,b.prod_price,b.prod_desc,b.prod_img FROM user_order as a, product as b WHERE a.pro_id = b.prod_id AND  a.order_no = %s"   
    cursor.execute(query, val)
    account = cursor.fetchall()
    print(account)
    total = sum([account[6] * account[11] for account in account])
    st = 1
    invno=account[0][4]    
    dv=account[0][7]
    conn.commit() 
    cursor.close()   
    response_data = {
        'total': total,
        'invno': invno,      
        'dv': dv,        
        'account': account,
    }
    return jsonify(response_data)     

@app.route('/getbycat', methods=['POST'])
def getbycat():
    if request.method == 'POST':
        m = request.form['m']
               
        cursor = conn.cursor()          
        coupon_offer_query = "SELECT a.*,b.cat_name FROM sub_category as a ,category as b WHERE a.cat_id=b.cat_id"
        cursor.execute(coupon_offer_query)        
        getallcat = cursor.fetchall()   
        print(getallcat)
        response = {
            
            "getallcat": getallcat
        }
        return jsonify(response)

@app.route('/catwise/<int:product_id>', methods=['GET'])
def catwise(product_id):
    try:
        cursor = conn.cursor()
        query = "SELECT * FROM product WHERE sub_cat_id = %s"
        cursor.execute(query, (product_id,))
        products_data = cursor.fetchall()
        # print(products) Check the retrieved products
        cursor.close()
        return render_template('fashionflair/cat_wise.html', products_data=products_data)
    
    except Exception as e:
        # Log the error or print it for debugging
        print("An error occurred:", str(e))
        return "An error occurred. Please check your server logs for more information."

@app.route("/customer-rating",methods=["POST"])
def customer_rating():
    if 'customer_id' not in session:
        return redirect(url_for('login'))
    customer_id = session['customer_id']
    product_id = request.form['prod_id']
    rating = request.form['rating']
    review = request.form['review']
    cursor = conn.cursor()
    query = "INSERT INTO review (user_id, prod_id, rating, review) VALUES (%s, %s, %s, %s)"
    val = (customer_id, product_id, rating, review)
    cursor.execute(query, val)
    conn.commit()
    return redirect(request.referrer)


@app.route("/order_cancel",methods=["POST"])
def order_cancel():
    order_id = request.form['order_id']
    customer_id = request.form['user_id']
    prod_id = request.form['pord_id']
    reason = request.form['reason']
    cursor = conn.cursor()
    query = "INSERT INTO canceled_orders (order_id,customer_id,prod_id,reason) VALUES (%s,%s,%s,%s)"
    val = (order_id,customer_id,prod_id,reason)
    cursor.execute(query,val)
    conn.commit()
    cursor.close()
    
    cursor = conn.cursor()
    query = "UPDATE user_order SET status = 1 WHERE order_no = %s "
    val = (order_id)
    cursor.execute(query,val)
    conn.commit()
    cursor.close()  
    msg = "Order cancellation successfull."
    return redirect(url_for('myorders',msg=msg))
    
@app.route('/admin/refund_req')
def refund_req():
    cursor = conn.cursor()
    
    # Merged Query: Fetch data from canceled_orders along with customer and product information
    query = """
    SELECT 
    canceled_orders.*,
    customers.name AS customer_name,
    customers.customer_email AS customer_email,
    product.prod_name,
    (user_order.qty * product.prod_price) - user_order.dv AS refundable_amount
    FROM 
        canceled_orders
    JOIN 
        customers ON canceled_orders.customer_id = customers.customer_id 
    JOIN 
        product ON canceled_orders.prod_id = product.prod_id
    JOIN 
        user_order ON canceled_orders.order_id = user_order.order_no;

    """
    cursor.execute(query)
    data = cursor.fetchall()
    msg = request.args.get('msg')
    
    return render_template('/admin/refund_req.html', data=data,msg=msg)


@app.route("/refund_payment", methods=['POST'])
def refund_payment():
    try:
        data = request.json
        order_no = data['order_no']
        total_amount = data['total_amount']
        name = data['name']
        email = data['email']
        
        cursor = conn.cursor()  
        delete_order_query = "DELETE FROM user_order WHERE order_no = %s"
        val = (order_no)
        cursor.execute(delete_order_query, val)
        conn.commit()
        cursor.close()
        
        cusrsor = conn.cursor()
        update_refund_req = "DELETE FROM canceled_orders WHERE order_id = %s"
        val2 = (order_no)
        cursor.execute(update_refund_req, val2)
        conn.commit()
        cursor.close()
        msg = "Refund payment successful."
        return redirect(url_for('refund_req',msg=msg))
    except Exception as e:
        # Handle exception
        msg = "Refund payment Unsuccessful."
        return redirect(url_for('refund_req',msg=msg))


# Define chatbot responses
responses = {
    "greeting": "Hello! How can I assist you today?",
    "search_products": "Sure, I can help you find products. What are you looking for?",
    "shipping": "Our standard shipping time is 3-5 business days.",
    "returns": "You can initiate a return within 30 days of purchase. Please visit our returns page for more information.",
    "thanks": "You're welcome! If you have any more questions, feel free to ask.",
    "default": "I'm sorry, I don't understand that. Can you please rephrase?",
    "issue" :"How can I help you with a payment issue?",
    "order_status": "To check the status of your order, please provide your order number.",
    "account_help": "For assistance with your account, such as password reset or account details update, please visit our account help page.",
    "product_details": "What specific details would you like to know about the product?",
    "contact_support": "If you need further assistance, please don't hesitate to contact our support team.",
    "payment_methods": "We accept various payment methods including credit/debit cards, PayPal, and bank transfers.",
    "discounts": "Currently, we have discounts available on selected items. Would you like to know more about them?",
    "size_guide": "To find the perfect fit, you can refer to our size guide available on the product page.",
    "customer_reviews": "Our customers love this product! You can read their reviews on the product page.",
    "gift_options": "Yes, we offer gift wrapping and personalized messages for your convenience.",
}

# Define intents and corresponding responses
intent_responses = {
    "hi": "greeting",
    "hiii": "greeting",
    "hello": "greeting",
    "hey": "greeting",
    "find products": "search_products",
    "search": "search_products",
    "product": "search_products",
    "shipping": "shipping",
    "delivery": "shipping",
    "return": "returns",
    "thanks": "thanks",
    "thank you": "thanks",
    "payment" : "issue",
    "order status": "order_status",
    "help": "account_help",
    "account": "account_help",
    "details": "product_details",
    "contact": "contact_support",
    "payment methods": "payment_methods",
    "discounts": "discounts",
    "size": "size_guide",
    "reviews": "customer_reviews",
    "gift": "gift_options",
}



# Chatbot route
@app.route('/chat', methods=['POST'])
def chat():
    # Get user message from request
    user_message = request.json.get('message', '')
    intent = get_intent(user_message)
    # Get chatbot response
    response = responses.get(intent, responses['default'])
    # Return response to UI
    return jsonify({'response': response})

def get_intent(message):
    message = message.lower()
    for keyword, intent in intent_responses.items():
        
        if fuzz.ratio(keyword, message) >= 90:  
            return intent
    
    # If no match found, return default intent
    return 'default'

@app.route("/admin/contacts")
def contacts():
    cursor  = conn.cursor()
    query = "SELECT * FROM contact_us"
    cursor.execute(query)
    data = cursor.fetchall()
    cursor.close()
    msg = request.args.get('msg')

    return render_template('admin/contacts.html',msg=msg,data=data)

@app.route("/admin/contacts_del",methods=["POST"])
def contacts_del():
    cn_id = request.form['cn_id']
    cursor  = conn.cursor()
    query = "DELETE FROM contact_us WHERE `contact_us`.`con_id` = %s"
    val = (cn_id)
    cursor.execute(query,val)
    conn.commit()

    cursor.close()
    msg = "deleted successfully"

    return redirect(url_for('contacts',msg=msg))


@app.route("/my_account")
def my_account():
    if 'customer_id' not in session:
        return redirect(url_for('login'))
    cursor = conn.cursor()
    user_id = session.get('customer_id')
    query = "SELECT distinct DISTINCT order_no, OrderDate, UserID, pro_id,status FROM user_order where UserID=%s"
    val=(user_id)
    cursor.execute(query,val)
    items = cursor.fetchall()
    cursor.close()

    cursor = conn.cursor()
    user_id = session.get('customer_id')
    query = "SELECT * FROM customers WHERE customer_id =%s"
    val=(user_id)
    cursor.execute(query,val)
    userdetials = cursor.fetchall()
    cursor.close()

    return render_template("fashionflair/my-account.html",items=items,ud=userdetials)

@app.route("/profile_edit", methods=["POST"])
def profile_edit():
    user_id = session.get('customer_id')
    name = request.form['name']
    email = request.form['email']
    password = request.form['password']
    cursor = conn.cursor()
    query = "UPDATE `customers` SET `name` = %s, customer_email = %s, customer_pwd = %s WHERE `customers`.`customer_id` = %s;"
    val = (name,email,password,user_id)
    cursor.execute(query,val)
    conn.commit()
    cursor.close()

    return redirect(url_for('my_account'))


@app.errorhandler(404)
def page_not_found(error):
    return render_template('fashionflair/404.html'), 404


if __name__ =='__main__':
    app.run(debug=True)